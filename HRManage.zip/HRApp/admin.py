from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Category)
admin.site.register(Job)
admin.site.register(RateApply)
admin.site.register(UserType)
admin.site.register(Company)
admin.site.register(Apply)
admin.site.register(InterviewCall)
